背景
我在做个人的产品设计师网站，打算上线后分享给招聘方，可能是中国或海外的企业的面试官作为我的个人介绍。有一个 figma 里设计了网站的结构和样式，请严格理解和还原还原我的交互设计细节和样式：
整体 figma 在：https://www.figma.com/design/byFHLgcOSVJ3SgztynU2Pq/lanaya-personal-web?node-id=192-3088
网站只有一个 home 页
	1	我需要网站有中英文切换的能力；
	1.1	我提供的是还没确定的默认内容版本（英文版），后续我会再提供中文版和最新的英文版内容给你，或者我直接在你的代码文件里改也可以，你到时候完成研发后告诉我在哪改；
	1.2	当用户点击下拉菜单切换语言时可以看到对应版本；
	1.3	切换语言的下拉菜单设计稿在 figma；
	2	主要内容包含（home 页整体设计在：https://www.figma.com/design/byFHLgcOSVJ3SgztynU2Pq/lanaya-personal-web?node-id=201-1253&t=9f1H1CTXkD4rUzz4-11，请严格按照我的设计实现）
	2.1	个人简介
		- 需要支持中英两版
	2.2	工作经历 list
		- 需要支持中英两版
	2.3	一个 “Project Detail 合集的入口” card
	- 文案需要支持中英两版
	- 点击这个 card 后，card 变长，出现密码输入框和下方关于获取密码方式的文本，card 上原有的图片的位置会变化，card 背景色会变化，具体看下方“一些设计和交互细节中的具体样式 figma 和说明）；
	- 输入密码后回车或点击右侧按钮进行验证；
	- 验证有问题就在输入框下方报错；
	- 如果密码验证没问题，在浏览器新页面打开对应的 Notion 的中文或英文版的数据库链接（根据上面提到的双语切换中对应的当前语言），目前我只做了中文版：https://www.notion.so/20258f61591a80a8bd47d569527b70ef?v=21d58f61591a80198a7b000c497dba0f&source=copy_link 未来会把英文版链接给你，暂时可以先让英文版打开的 project detail link 也对应这个 notion 链接
	- 点击浮窗外的区域可以将浮窗恢复到默认的卡片态
	3	一些设计和交互细节（注意：一定要还原 figma 到位！）：
	3.1	各状态的 project detail card 请严格按照设计稿来：
	3.1.1	默认态 card：@https://www.figma.com/design/byFHLgcOSVJ3SgztynU2Pq/lanaya-personal-web?node-id=192-1690&t=CuNtyNGoIFsy9tWT-11
	3.1.2	hover card 时会有 card 阴影变化，且光标变为小手，hover 态 card：https://www.figma.com/design/byFHLgcOSVJ3SgztynU2Pq/lanaya-personal-web?node-id=192-1690&t=9f1H1CTXkD4rUzz4-11；
	3.1.3	点击这个 card 后，card 变为激活态，card 变长，出现密码输入框和下方关于获取密码方式的文本，card 上原有的图片的位置会按设计稿变化，card 背景色会变为激活态的颜色（以下是对 figma 设计的解说，具体按照 figma 实现：激活态 card：@https://www.figma.com/design/byFHLgcOSVJ3SgztynU2Pq/lanaya-personal-web?node-id=192-1690&t=CuNtyNGoIFsy9tWT-11）
	3.1.3.1	card 上的 7 张图片摆放角度和位置需要按我给的 figma 设计来，以及角度变化过程直接从原角度变为新的角度就好
	3.1.3.2	网页最底部和 card 底部保持 72px 间距，在点击 card 时，默认变为激活态，card 变长，但底部依然与网页底部保持这个间距，因此网页随之变长；
	3.1.3.3	请判断用户的视窗位置下，卡片激活后的底部是否与屏幕底部保持了 40px 以上的空间，如果不够，请让卡片变高的同时，把整个视窗弹上到满足条件的位置（屏幕底部与 card 底部至少 40px 间距），方便看全整个卡片
	3.1.3.4	当激活态变为默认态时，card 和 网页的高度也随之变为原来的高度，网页视窗位置不变
	3.1.4	请严格参考：
	- 默认态 card：@https://www.figma.com/design/byFHLgcOSVJ3SgztynU2Pq/lanaya-personal-web?node-id=192-1690&t=CuNtyNGoIFsy9tWT-11
	- hover 态 card：https://www.figma.com/design/byFHLgcOSVJ3SgztynU2Pq/lanaya-personal-web?node-id=192-1690&t=9f1H1CTXkD4rUzz4-11
	- 激活态 card：@https://www.figma.com/design/byFHLgcOSVJ3SgztynU2Pq/lanaya-personal-web?node-id=192-1690&t=CuNtyNGoIFsy9tWT-11
	3.2	密码输入框的样式和位置按照设计稿实现：
	- 激活态 card 图中有输入框的位置，在激活 card 时，输入框和下方两行文字渐显出现：@https://www.figma.com/design/byFHLgcOSVJ3SgztynU2Pq/lanaya-personal-web?node-id=192-1690&t=CuNtyNGoIFsy9tWT-11
	- 输入框各态组件样式，请严格按照各状态来实现：@https://www.figma.com/design/byFHLgcOSVJ3SgztynU2Pq/lanaya-personal-web?node-id=192-1690&t=CuNtyNGoIFsy9tWT-11
	3.3	验证密码也请严格按照设计稿实现：
	- 输入密码后回车或点击右侧按钮进行验证，输入态设计稿：https://www.figma.com/design/byFHLgcOSVJ3SgztynU2Pq/lanaya-personal-web?node-id=192-1690&t=9f1H1CTXkD4rUzz4-11；
	- 验证有问题就在输入框下方报错，输入框设计稿：https://www.figma.com/design/byFHLgcOSVJ3SgztynU2Pq/lanaya-personal-web?node-id=192-1690&t=9f1H1CTXkD4rUzz4-11；
	- 如果密码验证没问题，卡片变化逻辑：
	- 变为 3 秒临时态，设计稿：https://www.figma.com/design/byFHLgcOSVJ3SgztynU2Pq/lanaya-personal-web?node-id=192-1690&t=9f1H1CTXkD4rUzz4-11，输入框和下方文案消失，变为一句话“Password entered correctly, new page opened 🙌🏼”，
	- 三秒后变回 card 默认态：https://www.figma.com/design/byFHLgcOSVJ3SgztynU2Pq/lanaya-personal-web?node-id=192-1690&t=9f1H1CTXkD4rUzz4-11；
	4	这些各类状态都在 figma 设计稿上有，包括各个状态下的输入框和 card，有问题读不到的话请告诉我，请不要自己编造元素或样式，严格按照我的设计实现。
