module.exports = {
  plugins: [
    'tailwindcss',
    'autoprefixer',
  ],
}; // 中文注释: PostCSS插件配置，使用对象格式并明确指定插件 